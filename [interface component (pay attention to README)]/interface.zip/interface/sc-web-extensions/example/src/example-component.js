ExampleComponent = {
    ext_lang: 'example_code',
    formats: ['format_example'],
    struct_support: true,

    factory: function (sandbox) {
        return new ExampleWindow(sandbox);
    }
};

ExampleWindow = function (sandbox) {

    this.sandbox = sandbox;
    this.sandbox.container = sandbox.container;

    const keynodes = ['ui_example_text_component', 'ui_example_search_component', 'ui_example_answer_button','ui_example_answer_button2',
    'ui_example_answer_button3','ui_example_answer_button4','ui_example_answer_button5','ui_example_info_block','ui_example_search_component2',
    'ui_example_search_component3','ui_example_answer_button6','ui_example_form2','ui_example_form2_com','ui_example_form2_bac','ui_example_form3'];
    
    const form2 = '#example-' + sandbox.container + " #form2";
    const form2_bac = '#example-' + sandbox.container + " #form2-bac";
    const form2_com = '#example-' + sandbox.container + " #form2-com";
    const form3 = '#example-' + sandbox.container + " #form3";

    const textComponent = '#example-' + sandbox.container + " #text-component";
    const searchComponent = '#example-' + sandbox.container + " #search-component";
    const answerButton = '#example-' + sandbox.container + " #answer-button";
    const answerButton2 = '#example-' + sandbox.container + " #answer-button2";
    const answerButton3 = '#example-' + sandbox.container + " #answer-button3";
    const answerButton4 = '#example-' + sandbox.container + " #answer-button4";
    const answerButton5 = '#example-' + sandbox.container + " #answer-button5";
    const keyword = '#example-' + sandbox.container + " #keyword";
    const searchComponent2 = '#example-' + sandbox.container + " #search-component2";
    const keyword2 = '#example-' + sandbox.container + " #keyword2";
    const searchComponent3 = '#example-' + sandbox.container + " #search-component3";
    const keyword3 = '#example-' + sandbox.container + " #keyword3";
    const answerButton6 = '#example-' + sandbox.container + " #answer-button6";
    const infoBlock = '#example-' + sandbox.container + " #info"

    const answerButton2_bac = '#example-' + sandbox.container + " #answer-button2-bac";
    const answerButton3_bac = '#example-' + sandbox.container + " #answer-button3-bac";
    const answerButton5_bac = '#example-' + sandbox.container + " #answer-button5-bac";

    $('#' + sandbox.container).prepend('<div id="example-' + sandbox.container + '"></div>');

    $('#example-' + sandbox.container).load('static/components/html/example.html', function () {
        getUIComponentsIdentifiers();

        $(answerButton).click(function (event) {
            event.preventDefault();
            let keywordText = $(keyword).val();

            if (keywordText) {
                findDeathRate(keywordText);
            }
        });
        $(answerButton2).click(function (event) {
            event.preventDefault();
            let keywordText = $(keyword).val();

            if (keywordText) {
                findMoreDeadlyDiseases(keywordText);
            }
        });
        $(answerButton3).click(function (event) {
            event.preventDefault();
            let keywordText = $(keyword).val();

            if (keywordText) {
                findLessDeadlyDiseases(keywordText);
            }
        });
        $(answerButton5).click(function (event) {
            event.preventDefault();
            let keywordText = $(keyword).val();

            if (keywordText) {
                findAsDeadlyDiseases(keywordText);
            }
        });

        $(answerButton2_bac).click(function (event) {
            event.preventDefault();
            let keywordText = $(keyword).val();

            if (keywordText) {
                findMoreDeadlyDiseases_bac(keywordText);
            }
        });
        $(answerButton3_bac).click(function (event) {
            event.preventDefault();
            let keywordText = $(keyword).val();

            if (keywordText) {
                findLessDeadlyDiseases_bac(keywordText);
            }
        });
        $(answerButton5_bac).click(function (event) {
            event.preventDefault();
            let keywordText = $(keyword).val();

            if (keywordText) {
                findAsDeadlyDiseases_bac(keywordText);
            }
        });
        $(answerButton4).click(function (event) {
            event.preventDefault();
            let keywordText = $(keyword).val();

            if (keywordText) {
                findSimilarDiseases(keywordText);
            }
        });
        $(answerButton6).click(function (event) {
            event.preventDefault();

            let lowerBoundString = $(keyword2).val();
            let upperBoundString = $(keyword3).val();

            if (lowerBoundString && upperBoundString) {
                let searchParams = {
                    lowerBound: lowerBoundString.toString(),
                    upperBound: upperBoundString.toString()
            };
            findDiseasesByBounds(searchParams);
        }   
        });
        
    });

    this.applyTranslation = function () {
        getUIComponentsIdentifiers();
    };

    function getUIComponentsIdentifiers() {
        SCWeb.core.Server.resolveScAddr(keynodes, function (keynodes) {
            SCWeb.core.Server.resolveIdentifiers(keynodes, function (identifiers) {

                let textComponentScAddr = keynodes['ui_example_text_component'];
                let textComponentText = identifiers[textComponentScAddr];
                $(textComponent).html(textComponentText);
                $(textComponent).attr('sc_addr', textComponentScAddr);

                let searchComponentScAddr = keynodes['ui_example_search_component'];
                let searchComponentText = identifiers[searchComponentScAddr];
                $(searchComponent).html(searchComponentText);
                $(searchComponent).attr('sc_addr', searchComponentScAddr);

                let searchComponentScAddr2 = keynodes['ui_example_search_component2'];
                let searchComponentText2 = identifiers[searchComponentScAddr2];
                $(searchComponent2).html(searchComponentText2);
                $(searchComponent2).attr('sc_addr', searchComponentScAddr2);

                let searchComponentScAddr3 = keynodes['ui_example_search_component3'];
                let searchComponentText3 = identifiers[searchComponentScAddr3];
                $(searchComponent3).html(searchComponentText3);
                $(searchComponent3).attr('sc_addr', searchComponentScAddr3);

                let form2text = identifiers[keynodes['ui_example_form2']];
                $(form2).html(form2text);
                let form3text = identifiers[keynodes['ui_example_form3']];
                $(form3).html(form3text);
                let form2text2 = identifiers[keynodes['ui_example_form2_bac']];
                $(form2_bac).html(form2text2);
                let form2text3 = identifiers[keynodes['ui_example_form2_com']];
                $(form2_com).html(form2text3);

                let answerButtonText = identifiers[keynodes['ui_example_answer_button']];
                $(answerButton).html(answerButtonText);
                let answerButtonText2 = identifiers[keynodes['ui_example_answer_button2']];
                $(answerButton2).html(answerButtonText2);
                let answerButtonText3 = identifiers[keynodes['ui_example_answer_button3']];
                $(answerButton3).html(answerButtonText3);
                let answerButtonText4 = identifiers[keynodes['ui_example_answer_button4']];
                $(answerButton4).html(answerButtonText4);
                let answerButtonText5 = identifiers[keynodes['ui_example_answer_button5']];
                $(answerButton5).html(answerButtonText5);
                let answerButtonText6 = identifiers[keynodes['ui_example_answer_button6']];
                $(answerButton6).html(answerButtonText6);

                $(answerButton2_bac).html(answerButtonText2);
                $(answerButton3_bac).html(answerButtonText3);
                $(answerButton5_bac).html(answerButtonText5);

                let infoBlockText = identifiers[keynodes['ui_example_info_block']];
                $(infoBlock).html(infoBlockText);
            });
        });
    }

    function findDeathRate(identifier) {
		console.log("findDeathrateLaunch");
		let nrel_ill_addr;
		let nrel_dead_addr;
		// Resolve sc-addrs.
		SCWeb.core.Server.resolveScAddr(['nrel_ill','nrel_dead',identifier], function (keynodes) {
            nrel_ill_addr=keynodes['nrel_ill']
            nrel_dead_addr=keynodes['nrel_dead']
            let keywordScAddr = keynodes[identifier];
            if (!keywordScAddr){
                return;
            }
            let illCount;
            let deadCount;

			window.sctpClient.iterate_elements(SctpIteratorType.SCTP_ITERATOR_5F_A_A_A_F, [
                keywordScAddr,
 				sc_type_arc_common | sc_type_const,
 				sc_type_link,
 				sc_type_arc_pos_const_perm,
 				nrel_dead_addr]).
			done(function(identifiers1){	 
				 window.sctpClient.get_link_content(identifiers1[0][2],'string').done(function(content){
				 	deadCount=Number(content);
                     window.sctpClient.iterate_elements(SctpIteratorType.SCTP_ITERATOR_5F_A_A_A_F, [
                         keywordScAddr,
                          sc_type_arc_common | sc_type_const,
                          sc_type_link,
                          sc_type_arc_pos_const_perm,
                          nrel_ill_addr]).
                     done(function(identifiers2){	 
                          window.sctpClient.get_link_content(identifiers2[0][2],'string').done(function(content){
                              illCount=Number(content);
                              let deathRate=deadCount/illCount
                           //   alert('Смертность для данного заболевания составляет: ' + deathRate);
                              document.getElementById('answer-button-result').innerHTML = 'Смертность для данного заболевания составляет: ' + deathRate
                          });			
                     });
				 });			
			});
		});
    }
    
    function findAnswer_temp() {
        const actionName = 'ui_menu_view_full_semantic_neighborhood_in_the_agreed_part_of_kb'; 
		console.log("findAnswer_temp_launch");
		// Resolve sc-addrs.
		SCWeb.core.Server.resolveScAddr(['placeholder_answer',actionName], function (keynodes) {
            let placeholdAnswAddr = keynodes['placeholder_answer'];
            let actionScAddr = keynodes[actionName];
            if (!placeholdAnswAddr){
                return;
            }

			window.sctpClient.iterate_elements(SctpIteratorType.SCTP_ITERATOR_3F_A_A, [
                placeholdAnswAddr,
 				sc_type_arc_pos_const_perm,
 				0]).
			done(function(result){	
                        
                        SCWeb.core.Main.doCommand(actionScAddr, [result[0][2]], function (result) {
                            // waiting for result
                            if (result.question !== undefined) {
                                // append in history
                                SCWeb.ui.WindowManager.appendHistoryItem(result.question);
                            }
                        });
                    });
				});	
            }

    function findMoreDeadlyDiseases(identifier) {
		console.log("findMoreDeadlyDiseasesLaunch");
		// Resolve sc-addrs.
		SCWeb.core.Server.resolveScAddr([identifier], function (keynodes) {

            let keywordScAddr = keynodes[identifier];

            if (!keywordScAddr){
                return;
            }

            SCWeb.core.Server.resolveScAddr(["ui_menu_search_operation2"], function (data) {
                // Get command of ui_menu_view_full_semantic_neighborhood
                let cmd = data["ui_menu_search_operation2"];
                console.log("cmd", cmd);
                // Simulate click on ui_menu_view_full_semantic_neighborhood button
                SCWeb.core.Main.doCommand(cmd, [keywordScAddr], function (result) {
                    // waiting for result
                    if (result.question != undefined) {
                        // append in history
                        consonle.log(result.question);
                        //SCWeb.ui.WindowManager.appendHistoryItem(result.question);/
                    }
                });
            });
		});
    }


    function findLessDeadlyDiseases(identifier) {
		console.log("findMoreDeadlyDiseasesLaunch");
		// Resolve sc-addrs.
		SCWeb.core.Server.resolveScAddr([identifier], function (keynodes) {

            let keywordScAddr = keynodes[identifier];

            if (!keywordScAddr){
                return;
            }

            SCWeb.core.Server.resolveScAddr(["ui_menu_search_operation3"], function (data) {
                // Get command of ui_menu_view_full_semantic_neighborhood
                let cmd = data["ui_menu_search_operation3"];
                console.log("cmd", cmd);
                // Simulate click on ui_menu_view_full_semantic_neighborhood button
                SCWeb.core.Main.doCommand(cmd, [keywordScAddr], function (result) {
                    // waiting for result
                    if (result.question != undefined) {
                        consonle.log(result.question);
                       // SCWeb.ui.WindowManager.appendHistoryItem(result.question);
                    }
                });
            });
		});
    }

    function findAsDeadlyDiseases(identifier) {
		console.log("findMoreDeadlyDiseasesLaunch");
		// Resolve sc-addrs.
		SCWeb.core.Server.resolveScAddr([identifier], function (keynodes) {

            let keywordScAddr = keynodes[identifier];

            if (!keywordScAddr){
                return;
            }

            SCWeb.core.Server.resolveScAddr(["ui_menu_search_operation5"], function (data) {
                // Get command of ui_menu_view_full_semantic_neighborhood
                let cmd = data["ui_menu_search_operation5"];
                console.log("cmd", cmd);
                // Simulate click on ui_menu_view_full_semantic_neighborhood button
                SCWeb.core.Main.doCommand(cmd, [keywordScAddr], function (result) {
                    // waiting for result
                    if (result.question != undefined) {
                        consonle.log(result.question);
                     //   SCWeb.ui.WindowManager.appendHistoryItem(result.question);
                    }
                });
            });
		});
    }

    function findSimilarDiseases(identifier) {
		console.log("findMoreDeadlyDiseasesLaunch");
		// Resolve sc-addrs.
		SCWeb.core.Server.resolveScAddr([identifier], function (keynodes) {

            let keywordScAddr = keynodes[identifier];

            if (!keywordScAddr){
                return;
            }

            SCWeb.core.Server.resolveScAddr(["ui_menu_search_operation4"], function (data) {
                // Get command of ui_menu_view_full_semantic_neighborhood
                let cmd = data["ui_menu_search_operation4"];
                console.log("cmd", cmd);
                // Simulate click on ui_menu_view_full_semantic_neighborhood button
                SCWeb.core.Main.doCommand(cmd, [keywordScAddr], function (result) {
                    // waiting for result
                    if (result.question != undefined) {
                        consonle.log(result.question);
                     //   SCWeb.ui.WindowManager.appendHistoryItem(result.question);
                    }
                });
            });
		});
    }


    function findDiseasesByBounds(searchParams) {
		    console.log(searchParams);
		    // create and assign 1st link.
            window.sctpClient.create_link().done(function(resLinkAddr1){
                let linkAddr1=resLinkAddr1;
                window.sctpClient.set_link_content(linkAddr1,searchParams.lowerBound).done(function(){
                    window.sctpClient.create_link().done(function(resLinkAddr2){
                        let linkAddr2=resLinkAddr2;
                        window.sctpClient.set_link_content(linkAddr2,searchParams.upperBound).done(function(){
                            SCWeb.core.Server.resolveScAddr(["ui_menu_search_operation6"], function (data) {
                                // Get command of ui_menu_view_full_semantic_neighborhood
                                let cmd = data["ui_menu_search_operation6"];
                                console.log("cmd", cmd);
                                // Simulate click on ui_menu_view_full_semantic_neighborhood button
                                SCWeb.core.Main.doCommand(cmd, [linkAddr1, linkAddr2], function (result) {
                                    // waiting for result

                                    if (result.question != undefined) {
                                        // append in history
                                        consonle.log(result.question);
                              //          SCWeb.ui.WindowManager.appendHistoryItem(result.question);
                                    }
                                });
                            });

                        })

                    })

                })

		    });
    }



    function findMoreDeadlyDiseases_bac(identifier) {
		console.log("findMoreDeadlyDiseasesLaunch");
		// Resolve sc-addrs.
		SCWeb.core.Server.resolveScAddr([identifier], function (keynodes) {

            let keywordScAddr = keynodes[identifier];

            if (!keywordScAddr){
                return;
            }

            SCWeb.core.Server.resolveScAddr(["ui_menu_search_operation2_bac"], function (data) {
                // Get command of ui_menu_view_full_semantic_neighborhood
                let cmd = data["ui_menu_search_operation2_bac"];
                console.log("cmd", cmd);
                // Simulate click on ui_menu_view_full_semantic_neighborhood button
                SCWeb.core.Main.doCommand(cmd, [keywordScAddr], function (result) {
                    // waiting for result
                    if (result.question != undefined) {
                        // append in history
                        consonle.log(result.question);
                        //SCWeb.ui.WindowManager.appendHistoryItem(result.question);/
                    }
                });
            });
		});
    }


    function findLessDeadlyDiseases_bac(identifier) {
		console.log("findMoreDeadlyDiseasesLaunch");
		// Resolve sc-addrs.
		SCWeb.core.Server.resolveScAddr([identifier], function (keynodes) {

            let keywordScAddr = keynodes[identifier];

            if (!keywordScAddr){
                return;
            }

            SCWeb.core.Server.resolveScAddr(["ui_menu_search_operation3_bac"], function (data) {
                // Get command of ui_menu_view_full_semantic_neighborhood
                let cmd = data["ui_menu_search_operation3_bac"];
                console.log("cmd", cmd);
                // Simulate click on ui_menu_view_full_semantic_neighborhood button
                SCWeb.core.Main.doCommand(cmd, [keywordScAddr], function (result) {
                    // waiting for result
                    if (result.question != undefined) {
                        consonle.log(result.question);
                       // SCWeb.ui.WindowManager.appendHistoryItem(result.question);
                    }
                });
            });
		});
    }

    function findAsDeadlyDiseases_bac(identifier) {
		console.log("findMoreDeadlyDiseasesLaunch");
		// Resolve sc-addrs.
		SCWeb.core.Server.resolveScAddr([identifier], function (keynodes) {

            let keywordScAddr = keynodes[identifier];

            if (!keywordScAddr){
                return;
            }

            SCWeb.core.Server.resolveScAddr(["ui_menu_search_operation5_bac"], function (data) {
                // Get command of ui_menu_view_full_semantic_neighborhood
                let cmd = data["ui_menu_search_operation5_bac"];
                console.log("cmd", cmd);
                // Simulate click on ui_menu_view_full_semantic_neighborhood button
                SCWeb.core.Main.doCommand(cmd, [keywordScAddr], function (result) {
                    // waiting for result
                    if (result.question != undefined) {
                        consonle.log(result.question);
                     //   SCWeb.ui.WindowManager.appendHistoryItem(result.question);
                    }
                });
            });
		});
    }


    this.sandbox.eventApplyTranslation = $.proxy(this.applyTranslation, this);
};

SCWeb.core.ComponentManager.appendComponentInitialize(ExampleComponent);
